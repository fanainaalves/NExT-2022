package br.org.cesar.aula7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
