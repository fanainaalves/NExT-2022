package next.projetoreferencia.utilidades;

public interface Identificavel {
	public long getIdentificador();
}
