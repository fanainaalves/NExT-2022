package next.projetoreferencia.utilidades;

public interface Comparavel {
	public int comparar(Comparavel comp);
}
