package next.projetoreferencia.telas;

public class ProgramaProdutoTipoProduto {

	public static void main(String[] args) {
		TelaSistema tela = new TelaSistema();
		tela.executarTela();
		System.exit(0);
	}
}
