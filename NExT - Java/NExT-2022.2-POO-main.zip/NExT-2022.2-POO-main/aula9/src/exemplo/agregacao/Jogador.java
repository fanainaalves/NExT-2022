package exemplo.agregacao;

public class Jogador {
    public String nome;

    public Jogador() {
        this.nome = "nome do jogador";
    }

}
