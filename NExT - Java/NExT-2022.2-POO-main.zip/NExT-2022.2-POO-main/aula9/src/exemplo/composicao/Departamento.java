package exemplo.composicao;

public class Departamento {

    public String nome;

    public Departamento(String nome) {
        this.nome = nome;
    }

}
