package pasta1.pasta2;

public class Conta {

    String numero;
    String conta;
    double saldo;
}
