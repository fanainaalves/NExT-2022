import pasta1.pasta2.Conta;

public class App {
    public static void main(String[] args) throws Exception {

        // tipo nome = criação do objeto
        Conta cBreno = new Conta();
        Conta cLeonardo = new Conta();
        Conta cGerson = new Conta();

        PessoaJuridica pj = new PessoaJuridica();

        pj.idade = 10234234;
        System.out.println(pj.idade);

    }
}
