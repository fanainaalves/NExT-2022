package exercicio3;

class Pessoa {
    int idade;
    String dataNascimento;
    String nome;

    void calcularIdade() {
        this.idade = 10;
    }
}
