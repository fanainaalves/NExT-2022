package exercicio1;

class Cliente {
    String cpf;
    String nome;
}