package exercicio1;

public class PrimeiroPrograma {

    public static void main(String[] args) {
        System.out.println("Meu primeiro programa em JAVA!");

    }

}
