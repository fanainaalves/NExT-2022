package coisas;

public class Pessoa {

}
