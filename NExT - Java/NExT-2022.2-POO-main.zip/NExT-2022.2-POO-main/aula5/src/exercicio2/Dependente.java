package exercicio2;

public class Dependente {

}
