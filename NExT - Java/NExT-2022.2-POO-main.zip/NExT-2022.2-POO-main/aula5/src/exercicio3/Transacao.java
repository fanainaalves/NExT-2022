package exercicio3;

public class Transacao {
    private double valor;
}
