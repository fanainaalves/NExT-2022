package exercicio3;

public class Cliente {
    private String nome;
    private String endereco;

    private Transacao[] lista_transacao;
}
