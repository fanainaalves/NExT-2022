package exemplo;

public class Empresa {
    private String CNPJ;
    private Funcionario lista_funcionario[];
}
