package exemplo;

public class Funcionario {

}
