package exemplo.composicao;

public class RecursosHumanos {
    public String nome;

    public RecursosHumanos(String nome) {
        this.nome = nome;
    }
}
