package exemplo.colaboracao;

public class Cliente {
    public int clienteId;
    public String nome;
    public String email;

    public Cliente(int clienteId) {
        this.clienteId = clienteId;
    }

}
