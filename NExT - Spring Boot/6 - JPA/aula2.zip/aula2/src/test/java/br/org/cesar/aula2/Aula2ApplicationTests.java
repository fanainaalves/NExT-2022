package br.org.cesar.aula2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
